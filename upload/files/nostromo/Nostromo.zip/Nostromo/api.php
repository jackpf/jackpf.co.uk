<?php
	/*
	 * http://www.jackpf.co.uk/ API
	 * 
	 */
	class jackpfAPI
	{
		var $uri, $auth, $call;
		function __construct()
		{
			$this->uri = 'http://www.jackpf.co.uk/bin/api.php';
			$this->auth = null;
		}
		function set_call($call)
		{
			$this->call = $call;
		}
		function exec()
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $this->uri.'?s='.$this->auth.'&call='.$this->call);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$return = curl_exec($ch);
			curl_close($ch);
			return $return;
		}
	}
?>