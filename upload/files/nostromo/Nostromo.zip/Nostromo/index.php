<?php
	//include api class
	include('api.php');
	//init api
	$api = new jackpfAPI;
	//set auth
	$api->auth = '7b0fde6320fcb692e131d734d9c3e276c37d3f09'; //Nostromo - this is your auth key!! Don't give it to anyone :P
	
	$api->set_call('get_info:Nostromo');
	$return = $api->exec();
	
	//function to sort out DOM
	function jackpf_apiDOM($e)
	{
		return strip_tags(reset($e));
	}
	
	//get online status
	preg_match('/\<Online\>(.*?)\<\/Online\>/', $return, $online);
	$online = jackpf_apiDOM($online);
	switch($online)
	{
		case 'true':
			echo 'I am online!';
		break;
		default:
			echo 'I am offline.';
		break;
	}
?>